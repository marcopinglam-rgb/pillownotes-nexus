# NEXUS pack for planning

This archive is background only. The person who uploaded it will state the requirement and the ultimate goal in a later message. Do not invent that goal from these files. Use the files to learn the product, the rules, and the current app, then plan against the goal they give you.

## What is newest

- Code is pillownotes-nexus branch cursor/verify-pillownotes-skill-ad92, commit e30d4de, 1 Nov 2026 10:03am Hong Kong time. It is two commits ahead of main. The live site pillownotes-nexus.vercel.app is still the older main build.
- Context is nexus-v2 main, commit d6399c8, 31 Oct 2026 8:42pm Hong Kong time.
- Read context/NEXUS_HANDOFF.md first, then context/NEXUS_TECHSTACK_AND_ISSUES.md, then context/AGENT.md.
- The newest case file in this pack is context/case_version_5.md. Rubric and judge files in the repo root stop at version 3 (rubric_version_3.md, judge_prompt_version_3.md). The handoff says those version numbers should match. They do not. Ask before treating a missing version as authoritative.
- App source is the code/ folder: index.html, app.js, styles.css, sw.js, manifest.webmanifest. Data lives in localStorage key nexusOS. There is no backend.
- code/.cursor/skills/verify-pillownotes/ is a harness for driving the mobile UI. It is not product behavior.

## How the two trees relate

- code/ is the mobile PWA to change when building the product.
- context/ is the competition brief, the scoring rules, the iteration log, the feature roadmap, and earlier HTML prototypes.
- context/sleep-app-baseline-v3/ is a separate sleep-companion demo line. context/sleep-app-baseline-v1/ and v2/ are earlier scored UI prototypes (HTML only in this pack).

## Left out on purpose

- Git history and .git, so no credentials and no stale commits.
- context/.hermes/, which holds older draft copies of rubrics and cases.
- 273 baseline PNG screenshots under sleep-app-baseline-v1/.
- Binary decks already extracted to text: AI_Future_Leader_PPT.txt, AIFL_Idea_OnePager_Chi.txt. The originals (pptx, pdf, docx) stay on GitHub in marcopinglam-rgb/nexus-v2.

## File list

code/app.js
code/assets/icon.svg
code/.cursor/skills/verify-pillownotes/features/mobile-tabs.md
code/.cursor/skills/verify-pillownotes/features/README.md
code/.cursor/skills/verify-pillownotes/features/save-dump.md
code/.cursor/skills/verify-pillownotes/features/sleep-checkpoint.md
code/.cursor/skills/verify-pillownotes/features/tonight.md
code/.cursor/skills/verify-pillownotes/features/wind-down.md
code/.cursor/skills/verify-pillownotes/scripts/pn-verify.mjs
code/.cursor/skills/verify-pillownotes/SKILL.md
code/.gitignore
code/index.html
code/manifest.webmanifest
code/README.md
code/styles.css
code/sw.js
code/vercel.json
code/Yi-Jian-Da-Kai-_Windows.bat
code/公开部署说明.md
context/AGENT.md
context/AIFL_Idea_OnePager_Chi.txt
context/AI_Future_Leader_PPT.txt
context/case_version_2.md
context/case_version_3.md
context/case_version_4.md
context/case_version_5.md
context/CURSOR_ACCESS_CHECKLIST.md
context/IDEA.md
context/iteration_log.md
context/judge_prompt_version_2.md
context/judge_prompt_version_3.md
context/NEXUS_HANDOFF.md
context/NEXUS_TECHSTACK_AND_ISSUES.md
context/README.md
context/rubric_version_2.md
context/rubric_version_3.md
context/sleep-app-baseline-v1/baseline-version-a-minimalist-dark.html
context/sleep-app-baseline-v1/baseline-version-b-soft-neumorphism.html
context/sleep-app-baseline-v1/baseline-version-c-nature-organic.html
context/sleep-app-baseline-v1/baseline-version-d-editorial-calm.html
context/sleep-app-baseline-v1/baseline-version-e-glassmorphism.html
context/sleep-app-baseline-v1/baseline-version-f-aurora-ui.html
context/sleep-app-baseline-v1/baseline-version-g-japandi.html
context/sleep-app-baseline-v1/baseline-version-h-warm-depth.html
context/sleep-app-baseline-v1/baseline-version-i-warm-depth-v2.html
context/sleep-app-baseline-v1/baseline-version-j-dusk-mist.html
context/sleep-app-baseline-v1/baseline-version-v11-teal-depth.html
context/sleep-app-baseline-v1/baseline-version-v12-plum-velvet.html
context/sleep-app-baseline-v1/baseline-version-v13-slate-minimal.html
context/sleep-app-baseline-v1/baseline-version-v14-sage-calm.html
context/sleep-app-baseline-v1/baseline-version-v15-navy-depth.html
context/sleep-app-baseline-v1/baseline-version-v16-dusty-rose.html
context/sleep-app-baseline-v1/baseline-version-v17-charcoal.html
context/sleep-app-baseline-v1/baseline-version-v18-forest-moss.html
context/sleep-app-baseline-v1/baseline-version-v19-fixed-foundation.html
context/sleep-app-baseline-v1/baseline-version-v20-focus-mode.html
context/sleep-app-baseline-v1/baseline-version-v21-history-first.html
context/sleep-app-baseline-v1/baseline-version-v22-persistent-composer.html
context/sleep-app-baseline-v1/baseline-version-v23-timeline-editor.html
context/sleep-app-baseline-v1/baseline-version-v25-checkpoint-first.html
context/sleep-app-baseline-v1/baseline-version-v25-steel.html
context/sleep-app-baseline-v1/baseline-version-v26-olive.html
context/sleep-app-baseline-v1/baseline-version-v26-voice-first.html
context/sleep-app-baseline-v1/baseline-version-v27-lavender.html
context/sleep-app-baseline-v1/baseline-version-v27-split-layout.html
context/sleep-app-baseline-v1/baseline-version-v28-sheet-entry.html
context/sleep-app-baseline-v1/baseline-version-v29-immersive.html
context/sleep-app-baseline-v1/baseline-version-v30-thumb-zone.html
context/sleep-app-baseline-v1/baseline-version-v31-voice-composer.html
context/sleep-app-baseline-v1/baseline-version-v32-quick-tags.html
context/sleep-app-baseline-v1/baseline-version-v33-sleep-recap.html
context/sleep-app-baseline-v1/baseline-version-v34-center-plus.html
context/sleep-app-baseline-v1/baseline-version-v35-quick-check.html
context/sleep-app-baseline-v1/baseline-version-v35-teal.html
context/sleep-app-baseline-v1/baseline-version-v36-thought-bar.html
context/sleep-app-baseline-v1/baseline-version-v37-indigo.html
context/sleep-app-baseline-v1/baseline-version-v37-night-flow.html
context/sleep-app-baseline-v1/baseline-version-v38-teal-accordion.html
context/sleep-app-baseline-v1/baseline-version-v39-voice-only.html
context/sleep-app-baseline-v1/baseline-version-v40-dual-sheet.html
context/sleep-app-baseline-v1/baseline-version-v40-rose.html
context/sleep-app-baseline-v1/baseline-version-v41-split-dump.html
context/sleep-app-baseline-v1/baseline-version-v42-sleep-widgets.html
context/sleep-app-baseline-v1/baseline-version-v43-auto-bar.html
context/sleep-app-baseline-v1/baseline-version-v44-mood-dump.html
context/sleep-app-baseline-v1/baseline-version-v45-night-focus.html
context/sleep-app-baseline-v1/baseline-version-v46-sleep-graph.html
context/sleep-app-baseline-v1/baseline-version-v47-one-hand.html
context/sleep-app-baseline-v1/baseline-version-v48-minimal.html
context/sleep-app-baseline-v1/baseline-version-v49-dream.html
context/sleep-app-baseline-v1/baseline-version-v50-final.html
context/sleep-app-baseline-v1/baseline-version-v51-overlay-bar.html
context/sleep-app-baseline-v1/screenshot_all.py
context/sleep-app-baseline-v1/screenshot_h.py
context/sleep-app-baseline-v1/screenshot_i.py
context/sleep-app-baseline-v1/screenshot_j.py
context/sleep-app-baseline-v1/screenshot_round2.py
context/sleep-app-baseline-v2/baseline-v52-foundation-fix.html
context/sleep-app-baseline-v2/baseline-v53-card-grid.html
context/sleep-app-baseline-v2/baseline-v54-today-timeline.html
context/sleep-app-baseline-v2/baseline-v55-mood-first.html
context/sleep-app-baseline-v2/baseline-v56-swipe-dump.html
context/sleep-app-baseline-v2/baseline-v57-split-settings.html
context/sleep-app-baseline-v2/baseline-v58-quick-chips.html
context/sleep-app-baseline-v2/baseline-v59-breathing-wd.html
context/sleep-app-baseline-v2/baseline-v60-accordion-all.html
context/sleep-app-baseline-v2/baseline-v61-grid-dash.html
context/sleep-app-baseline-v2/baseline-v62-v-stack-dash.html
context/sleep-app-baseline-v2/baseline-v63-h-timeline.html
context/sleep-app-baseline-v2/baseline-v64-step-flow-wd.html
context/sleep-app-baseline-v2/baseline-v65-list-dump.html
context/sleep-app-baseline-v2/baseline-v66-tab-settings.html
context/sleep-app-baseline-v2/baseline-v67-mood+h-tl.html
context/sleep-app-baseline-v2/baseline-v68-grid+breath.html
context/sleep-app-baseline-v2/baseline-v69-vstack+accordion.html
context/sleep-app-baseline-v2/baseline-v70-minimalist.html
context/sleep-app-baseline-v2/baseline-v71-pill-nav-dash.html
context/sleep-app-baseline-v2/baseline-v72-progress-ring.html
context/sleep-app-baseline-v2/baseline-v73-stats-first.html
context/sleep-app-baseline-v2/baseline-v74-carousel-dash.html
context/sleep-app-baseline-v2/baseline-v75-segmented-sleep.html
context/sleep-app-baseline-v2/baseline-v76-two-col-dump.html
context/sleep-app-baseline-v2/baseline-v77-checklist-wd.html
context/sleep-app-baseline-v2/baseline-v78-fab-float.html
context/sleep-app-baseline-v2/baseline-v79-summary-hero.html
context/sleep-app-baseline-v2/baseline-v80-compact-sleep.html
context/sleep-app-baseline-v2/baseline-v81-deep-navy.html
context/sleep-app-baseline-v2/baseline-v82-moss-calm.html
context/sleep-app-baseline-v2/baseline-v83-rose-warm.html
context/sleep-app-baseline-v2/baseline-v84-slate-cool.html
context/sleep-app-baseline-v2/baseline-v85-indigo-night.html
context/sleep-app-baseline-v2/baseline-v86-radial-menu.html
context/sleep-app-baseline-v2/baseline-v87-banner-style.html
context/sleep-app-baseline-v2/baseline-v88-night-glow.html
context/sleep-app-baseline-v2/baseline-v89-soft-dark.html
context/sleep-app-baseline-v2/baseline-v90-calm-blue.html
context/sleep-app-baseline-v2/baseline-v91-mist-green.html
context/sleep-app-baseline-v2/baseline-v92-warm-dusk.html
context/sleep-app-baseline-v2/baseline-v93-ocean-deep.html
context/sleep-app-baseline-v2/baseline-v94-slate-night.html
context/sleep-app-baseline-v2/baseline-v95-pure-dark.html
context/sleep-app-baseline-v2/gen_variants.py
context/sleep-app-baseline-v3/candidate-a-memo-first.html
context/sleep-app-baseline-v3/candidate-b-reflection-first.html
context/sleep-app-baseline-v3/.gitignore
context/sleep-app-baseline-v3/index.html
context/sleep-app-baseline-v3/sleep-companion-demo01.html
context/sleep-app-baseline-v3/vercel.json
context/sleep_app_feature_roadmap.csv
